import { createFileRoute } from '@tanstack/react-router'
import { useMutation, useQuery } from '@tanstack/react-query'
import html2canvas from 'html2canvas'
import { Plus, RefreshCw, Trash2 } from 'lucide-react'
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { z } from 'zod'
import { saveBillWithItems } from '@/data/bills'
import { pb } from '@/data/pocketbase'
import { calculateBillTotalFromBase, calculateBillTotals } from '@/domain/billing-calculations'
import { useMarketRate } from '@/domain/market-rate'
import { getLocalIsoDate } from '@/lib/date'
import { formatInQty, formatInrInteger, parseNonNegativeNumber, parsePositiveIntInput } from '@/lib/inr-format'

export const Route = createFileRoute('/new-bill')({
  component: NewBillPage,
})

type CustomerOption = { id: string; name: string }
type ItemOption = { id: string; name: string; defaultRate: number }
type BillItemRow = { itemName: string; qty: number; rate: number; manualRateEdited: boolean }
type CreditAdjustment = { date: string; amount: number }
type AutoBalanceContext = { previousBalanceDate: string; previousBalanceAmount: number; credits: CreditAdjustment[] }
type PBRecord = Record<string, unknown> & { id: string }
const num = (v: unknown) => (Number.isFinite(Number(v ?? 0)) ? Number(v) : 0)
const datePart = (v: unknown) => String(v ?? '').slice(0, 10)
const COMPANY_NAME = 'Kapil Trading Co.'
const submitRowSchema = z.object({
  itemName: z.string().trim().min(1),
  qty: z.number().positive(),
  rate: z.number().positive(),
})

const submitBillSchema = z.object({
  customerId: z.string().trim().min(1, 'Please select a customer'),
  bookNo: z.number().int().positive('Book No is required'),
  billNo: z.number().int().positive('Bill No is required'),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid bill date'),
  items: z.array(submitRowSchema).min(1, 'Add at least one valid item row'),
})

function NewBillPage() {
  const today = useMemo(() => getLocalIsoDate(), [])
  const [bookNo, setBookNo] = useState<number>(51)
  const [billNo, setBillNo] = useState<number>(1)
  const [date, setDate] = useState(today)
  const [customerId, setCustomerId] = useState('')
  const [mktRate, setMktRate] = useState<number>(0)
  const [transport, setTransport] = useState<number>(0)
  const [gstRate, setGstRate] = useState<number>(0)
  const [lrInput, setLrInput] = useState('')
  const [lrList, setLrList] = useState<string[]>([])
  const [rows, setRows] = useState<BillItemRow[]>([{ itemName: '', qty: 0, rate: 0, manualRateEdited: false }])
  const [statusText, setStatusText] = useState('')
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const { marketRate, refreshMarketRate } = useMarketRate()
  const billNoInitializedRef = useRef(false)
  const previewRef = useRef<HTMLDivElement>(null)

  const customersQuery = useQuery({
    queryKey: ['customers-options'],
    queryFn: async (): Promise<CustomerOption[]> => {
      const records = await pb.collection('customers').getFullList({ sort: 'name' })
      return records.map((r) => ({ id: r.id, name: String(r.name ?? '') }))
    },
  })

  const itemsQuery = useQuery({
    queryKey: ['items-options'],
    queryFn: async (): Promise<ItemOption[]> => {
      const records = await pb.collection('items').getFullList({ sort: 'name' })
      return records.map((r) => ({
        id: r.id,
        name: String(r.name ?? ''),
        defaultRate: Number(r.default_rate ?? 0),
      }))
    },
  })

  const latestBillNoQuery = useQuery({
    queryKey: ['latest-bill-no'],
    queryFn: async (): Promise<number> => {
      const page = await pb.collection('bills').getList(1, 1, { sort: '-bill_no' })
      const record = page.items[0]
      return Number(record?.bill_no ?? 0)
    },
  })
  const autoBalanceQuery = useQuery({
    queryKey: ['customer-auto-balance', customerId, date],
    enabled: Boolean(customerId && date),
    queryFn: async (): Promise<AutoBalanceContext> => {
      const [billsRaw, billItemsRaw, paymentsRaw] = await Promise.all([
        pb.collection('bills').getFullList({
          sort: 'date,bill_no',
          filter: `customer = "${customerId}" && date <= "${date}"`,
        }),
        pb.collection('bill_items').getFullList(),
        pb.collection('payments').getFullList({
          sort: 'date',
          filter: `customer = "${customerId}" && date <= "${date}"`,
        }),
      ])
      const customerRecord = await pb.collection('customers').getOne(customerId)

      const bills = billsRaw as PBRecord[]
      const billItems = billItemsRaw as PBRecord[]
      const payments = (paymentsRaw as PBRecord[]).map((payment) => ({
        date: datePart(payment.date),
        amount: num(payment.amount),
      }))
      const openingBalance = num(customerRecord.opening_balance)

      const priorBills = bills.filter((bill) => datePart(bill.date) < date)
      if (priorBills.length === 0) {
        const openingCredits = payments.filter((entry) => entry.amount > 0)
        return { previousBalanceDate: 'Opening', previousBalanceAmount: openingBalance, credits: openingCredits }
      }

      const itemTotalByBill = new Map<string, number>()
      for (const row of billItems) {
        const billId = String(row.bill ?? '')
        itemTotalByBill.set(billId, (itemTotalByBill.get(billId) ?? 0) + num(row.amount))
      }

      const lastBill = priorBills[priorBills.length - 1]
      const lastBillDate = datePart(lastBill.date)
      const billTotals = priorBills.map((bill) => ({
        date: datePart(bill.date),
        total: calculateBillTotalFromBase(itemTotalByBill.get(bill.id) ?? 0, num(bill.transport), num(bill.gst_rate)),
      }))

      const billedUntilLastBill = billTotals.reduce((sum, entry) => sum + entry.total, 0)
      const paidUntilLastBill = payments.filter((entry) => entry.date <= lastBillDate).reduce((sum, entry) => sum + entry.amount, 0)
      const previousBalanceAmount = openingBalance + billedUntilLastBill - paidUntilLastBill
      const credits = payments.filter((entry) => entry.date > lastBillDate && entry.date <= date && entry.amount > 0)

      return {
        previousBalanceDate: lastBillDate || date,
        previousBalanceAmount,
        credits,
      }
    },
  })

  const saveMutation = useMutation({
    mutationFn: async () => {
      const customer = (customersQuery.data ?? []).find((c) => c.id === customerId)
      if (!customer) throw new Error('Please select a customer')
      const validRows = rows.filter((r) => r.itemName.trim() && r.qty > 0 && r.rate > 0)
      const parsed = submitBillSchema.safeParse({
        customerId,
        bookNo,
        billNo,
        date,
        items: validRows,
      })
      if (!parsed.success) {
        throw new Error(parsed.error.issues[0]?.message ?? 'Bill validation failed')
      }

      await saveBillWithItems({
        bookNo,
        billNo,
        date,
        customerId: customer.id,
        customerName: customer.name,
        mktRate,
        transport,
        gstRate,
        lrList,
        items: validRows,
      })
    },
    onSuccess: () => {
      setStatusText('Bill saved successfully')
      resetForm()
    },
    onError: (err) => {
      setStatusText(err instanceof Error ? err.message : 'Failed to save bill')
    },
  })

  const totals = useMemo(() => {
    return calculateBillTotals({
      items: rows,
      transport,
      gstRate,
    })
  }, [rows, gstRate, transport])

  const helperStatusText = useMemo(() => {
    if (statusText) return statusText
    const hasCustomer = Boolean(customerId)
    const hasValidRow = rows.some((r) => r.itemName && r.qty > 0 && r.rate > 0)
    return hasCustomer && hasValidRow ? 'Ready to save' : 'Fill required fields to save'
  }, [statusText, customerId, rows])
  const selectedCustomerName = (customersQuery.data ?? []).find((c) => c.id === customerId)?.name ?? 'Unknown'
  const validRows = rows.filter((r) => r.itemName.trim() && r.qty > 0 && r.rate > 0)
  const previousBalanceDate = autoBalanceQuery.data?.previousBalanceDate ?? date
  const previousBalanceAmount = autoBalanceQuery.data?.previousBalanceAmount ?? 0
  const validCredits = (autoBalanceQuery.data?.credits ?? []).filter((entry) => entry.amount > 0)
  const totalCredits = validCredits.reduce((sum, entry) => sum + entry.amount, 0)
  const subTotalBeforeCredits = totals.grandTotal + previousBalanceAmount
  const payableAfterAdjustments = totals.grandTotal + previousBalanceAmount - totalCredits
  const previewLineItems = useMemo(
    () => [
      { particulars: `MKT : ${Math.round(mktRate) || 0}`, qty: '', rate: '', amount: '', isMeta: true },
      ...validRows.map((row) => ({
        particulars: row.itemName,
        qty: `${row.qty} kg`,
        rate: `${Math.round(row.rate)}`,
        amount: `${Math.round(row.qty * row.rate)}`,
        isMeta: false,
      })),
      ...(totals.transport > 0
        ? [{ particulars: 'Transport', qty: '', rate: '+', amount: `${Math.round(totals.transport)}`, isMeta: true as const }]
        : []),
      ...(totals.gstAmount > 0
        ? [{ particulars: `GST ${gstRate}%`, qty: '', rate: '+', amount: `${Math.round(totals.gstAmount)}`, isMeta: true as const }]
        : []),
      {
        particulars: `Pre [${previousBalanceDate}]`,
        qty: '',
        rate: previousBalanceAmount >= 0 ? '+' : '-',
        amount: `${Math.round(Math.abs(previousBalanceAmount))}`,
        isMeta: true as const,
      },
      ...(validCredits.length > 0
        ? validCredits.map((entry) => ({
            particulars: `Cr [${entry.date}]`,
            qty: '',
            rate: '-',
            amount: `${Math.round(entry.amount)}`,
            isMeta: true as const,
          }))
        : [{ particulars: 'Cr [No credits in this period]', qty: '', rate: '-', amount: '0', isMeta: true as const }]),
    ],
    [mktRate, validRows, totals.transport, totals.gstAmount, gstRate, previousBalanceAmount, previousBalanceDate, validCredits],
  )

  function resetForm() {
    setDate(today)
    setCustomerId('')
    setMktRate(0)
    setTransport(0)
    setGstRate(0)
    setRows([{ itemName: '', qty: 0, rate: 0, manualRateEdited: false }])
    setLrInput('')
    setLrList([])
    setBillNo((prev) => prev + 1)
  }

  function addLrChip() {
    const next = lrInput.trim()
    if (!next) return
    if (!lrList.includes(next)) setLrList((prev) => [...prev, next])
    setLrInput('')
  }


  function addItemRow() {
    setRows((prev) => [...prev, { itemName: '', qty: 0, rate: 0, manualRateEdited: false }])
  }

  function removeItemRow(index: number) {
    setRows((prev) => (prev.length <= 1 ? prev : prev.filter((_, i) => i !== index)))
  }

  function updateRow(index: number, patch: Partial<BillItemRow>) {
    setRows((prev) => prev.map((row, i) => (i === index ? { ...row, ...patch } : row)))
  }

  function validateBeforePreview() {
    const parsed = submitBillSchema.safeParse({
      customerId,
      bookNo,
      billNo,
      date,
      items: validRows,
    })
    if (!parsed.success) {
      setStatusText(parsed.error.issues[0]?.message ?? 'Bill validation failed')
      return false
    }
    return true
  }

  function openPreview() {
    if (!validateBeforePreview()) return
    setStatusText('')
    setIsPreviewOpen(true)
  }

  async function confirmAndSave() {
    try {
      await saveMutation.mutateAsync()
      setIsPreviewOpen(false)
    } catch {
      // saveMutation handles error state text.
    }
  }

  function printPreview() {
    const previewElement = previewRef.current
    if (!previewElement) return
    const printWindow = window.open('', '_blank', 'noopener,noreferrer,width=900,height=800')
    if (!printWindow) {
      setStatusText('Unable to open print window')
      return
    }
    printWindow.document.write(`
      <html>
        <head>
          <title>Bill Preview</title>
          <style>
            @page { size: 11cm 18cm; margin: 0.25cm; }
            body { margin: 0; padding: 0; font-family: Arial, sans-serif; color: #0f172a; background: #fff; }
            .preview-print { width: 10.5cm; min-height: 17.5cm; margin: 0 auto; }
            table { border-collapse: collapse; width: 100%; font-size: 10px; }
            th, td { border: 1px solid #cbd5e1; padding: 3px 4px; text-align: left; vertical-align: top; }
            .amount { text-align: right; font-family: monospace; }
          </style>
        </head>
        <body><div class="preview-print">${previewElement.innerHTML}</div></body>
      </html>
    `)
    printWindow.document.close()
    printWindow.focus()
    printWindow.print()
  }

  async function savePreviewAsJpg() {
    const previewElement = previewRef.current
    if (!previewElement) return
    const canvas = await html2canvas(previewElement, { scale: 2, backgroundColor: '#ffffff' })
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92)
    const link = document.createElement('a')
    link.href = dataUrl
    link.download = `bill-preview-${bookNo}-${billNo}.jpg`
    link.click()
  }

  function shareOnWhatsApp() {
    const billRef = `${String(bookNo).padStart(3, '0')}/${String(billNo).padStart(3, '0')}`
    const message = [
      `${COMPANY_NAME}`,
      `Bill Ref: ${billRef}`,
      `Party: ${selectedCustomerName}`,
      `Bill Date: ${date}`,
      `Current Bill: ${formatInrInteger(totals.grandTotal)}`,
      `${previousBalanceAmount >= 0 ? 'Previous Balance' : 'Previous Advance'}: ${formatInrInteger(Math.abs(previousBalanceAmount))} (${previousBalanceDate})`,
      `Payments Adjusted: ${formatInrInteger(totalCredits)}`,
      `${payableAfterAdjustments >= 0 ? 'Amount Due' : 'Advance Balance'}: ${formatInrInteger(Math.abs(payableAfterAdjustments))}`,
    ].join('\n')
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')
  }

  useEffect(() => {
    if (marketRate.rate > 0) {
      setMktRate(marketRate.rate)
    }
  }, [marketRate.rate])

  useEffect(() => {
    if (billNoInitializedRef.current) return
    if (latestBillNoQuery.isLoading) return
    const latest = Number(latestBillNoQuery.data ?? 0)
    setBillNo(latest > 0 ? latest + 1 : 1)
    billNoInitializedRef.current = true
  }, [latestBillNoQuery.data, latestBillNoQuery.isLoading])

  useEffect(() => {
    const items = itemsQuery.data ?? []
    if (items.length === 0) return
    setRows((prev) =>
      prev.map((row) => {
        if (!row.itemName || row.manualRateEdited) return row
        const selected = items.find((it) => it.name === row.itemName)
        if (!selected) return row
        return { ...row, rate: selected.defaultRate + mktRate }
      }),
    )
  }, [mktRate, itemsQuery.data])

  return (
    <div className="w-full space-y-6 px-4 pb-10 pt-4 md:px-6">
      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Jamnagar Local Rate</p>
            <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">{formatInrInteger(marketRate.rate)}</p>
            <p className="text-xs text-slate-500">{marketRate.rateDate}</p>
          </div>
          <button
            type="button"
            className="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
            onClick={() => {
              void refreshMarketRate().then((ok) => {
                if (ok) {
                  setStatusText('Market rate updated from RSS')
                } else {
                  setStatusText('Could not fetch RSS rate')
                }
              })
            }}
          >
            <RefreshCw size={14} />
            Refresh Rate
          </button>
        </div>
      </section>

      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 text-sm font-semibold text-slate-900">Bill Details</h3>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
          <Field label="Book No">
            <input className={inputClass} type="number" value={bookNo} onChange={(e) => setBookNo(parseNonNegativeNumber(e.target.value))} />
          </Field>
          <Field label="Bill No">
            <input className={inputClass} type="number" value={billNo} onChange={(e) => setBillNo(parseNonNegativeNumber(e.target.value))} />
          </Field>
          <Field label="Date">
            <input className={inputClass} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="Customer">
            <select className={inputClass} value={customerId} onChange={(e) => setCustomerId(e.target.value)} disabled={customersQuery.isLoading || customersQuery.isError}>
              <option value="">Select customer...</option>
              {customersQuery.isLoading && <option value="" disabled>Loading customers...</option>}
              {customersQuery.isError && <option value="" disabled>Unable to load customers</option>}
              {!customersQuery.isLoading && !customersQuery.isError && (customersQuery.data ?? []).length === 0 && <option value="" disabled>No customers found</option>}
              {(customersQuery.data ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="MKT Rate">
            <input className={inputClass} type="number" value={mktRate} onChange={(e) => setMktRate(parseNonNegativeNumber(e.target.value))} />
          </Field>
          <Field label="Transport (INR) (optional)">
            <input className={inputClass} type="number" value={transport} onChange={(e) => setTransport(parseNonNegativeNumber(e.target.value))} />
          </Field>
          <Field label="GST (optional)">
            <select className={inputClass} value={gstRate} onChange={(e) => setGstRate(Number(e.target.value))}>
              <option value={0}>No GST</option>
              <option value={5}>5%</option>
              <option value={12}>12%</option>
              <option value={18}>18%</option>
            </select>
          </Field>
          <Field label="Previous Balance Date (auto)">
            <input className={`${inputClass} bg-slate-50`} type="text" value={previousBalanceDate} readOnly />
          </Field>
          <Field label="Previous Balance Amount (auto)">
            <input className={`${inputClass} bg-slate-50`} type="text" value={formatInrInteger(previousBalanceAmount)} readOnly />
          </Field>
          <Field label="LR Numbers (optional)">
            <div className="flex min-w-0 items-center gap-2">
              <input
                className={inputClass}
                type="text"
                value={lrInput}
                onChange={(e) => setLrInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault()
                    addLrChip()
                  }
                }}
                placeholder="Enter LR No"
              />
              <button
                type="button"
                className="h-10 shrink-0 rounded-md border border-slate-300 bg-slate-50 px-4 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
                onClick={addLrChip}
              >
                Add
              </button>
            </div>
          </Field>
        </div>
        {lrList.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {lrList.map((lr) => (
              <span
                key={lr}
                title={lr}
                className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50/80 pl-2.5 pr-1.5 py-1 text-xs text-slate-800"
              >
                <span className="min-w-0 max-w-[12rem] truncate font-medium">{lr}</span>
                <button
                  type="button"
                  className="shrink-0 rounded p-0.5 text-slate-500 transition hover:bg-red-50 hover:text-red-600"
                  aria-label={`Remove ${lr}`}
                  onClick={() => setLrList((prev) => prev.filter((v) => v !== lr))}
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
        <div className="mt-4 rounded-md border border-slate-200 bg-slate-50 p-3">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Credit Entries (auto)</p>
            {autoBalanceQuery.isFetching && <span className="text-xs text-slate-500">Loading...</span>}
          </div>
          <div className="space-y-1 text-sm text-slate-700">
            {!customerId && <p>Select customer to load credit history.</p>}
            {customerId && autoBalanceQuery.isSuccess && (
              <p>
                Previous balance as on <span className="font-semibold">{previousBalanceDate}</span>:{' '}
                <span className="font-mono font-semibold">{formatInrInteger(previousBalanceAmount)}</span>
              </p>
            )}
            {customerId && !autoBalanceQuery.isFetching && validCredits.length === 0 && <p>No credits found after last bill date.</p>}
            {validCredits.map((entry, index) => (
              <div key={`${entry.date}-${entry.amount}-${index}`} className="flex items-center justify-between rounded-md border border-slate-200 bg-white px-2 py-1.5">
                <span className="font-medium">{entry.date}</span>
                <span className="font-mono text-slate-900">- {formatInrInteger(entry.amount)}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900">Items</h3>
          <button type="button" className="inline-flex items-center gap-1 rounded-md border border-slate-300 bg-slate-50 px-3 py-1.5 text-sm text-slate-700" onClick={addItemRow}>
            <Plus size={14} /> Add Row
          </button>
        </div>
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full min-w-[760px] table-fixed border-separate border-spacing-x-2 border-spacing-y-0">
            <colgroup>
              <col className="w-[44%]" />
              <col className="w-[16%]" />
              <col className="w-[16%]" />
              <col className="w-[24%]" />
              <col className="w-[72px]" />
            </colgroup>
            <thead>
              <tr className="bg-slate-50">
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Item</th>
                <th className="px-3 py-2.5 text-right text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Qty</th>
                <th className="px-3 py-2.5 text-right text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Rate</th>
                <th className="px-3 py-2.5 text-right text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Amount</th>
                <th className="px-3 py-2.5 text-center text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => {
                const amount = row.qty * row.rate
                return (
                  <tr key={i} className="border-t border-slate-100">
                    <td className="px-3 py-2.5 align-middle">
                      <select
                        className={inputClass}
                        value={row.itemName}
                        disabled={itemsQuery.isLoading || itemsQuery.isError}
                        onChange={(e) => {
                          const itemName = e.target.value
                          const selected = (itemsQuery.data ?? []).find((it) => it.name === itemName)
                          updateRow(i, {
                            itemName,
                            rate: selected ? selected.defaultRate + mktRate : row.rate,
                            manualRateEdited: false,
                          })
                        }}
                      >
                        <option value="">Select item...</option>
                        {itemsQuery.isLoading && <option value="" disabled>Loading items...</option>}
                        {itemsQuery.isError && <option value="" disabled>Unable to load items</option>}
                        {!itemsQuery.isLoading && !itemsQuery.isError && (itemsQuery.data ?? []).length === 0 && <option value="" disabled>No items found</option>}
                        {(itemsQuery.data ?? []).map((it) => (
                          <option key={it.id} value={it.name}>
                            {it.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="px-3 py-2.5 align-middle">
                      <input
                        className={`${inputClass} text-right tabular-nums`}
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        autoComplete="off"
                        value={row.qty === 0 ? '' : String(row.qty)}
                        onChange={(e) => updateRow(i, { qty: parsePositiveIntInput(e.target.value) })}
                        onBlur={() => {
                          if (row.qty === 0) updateRow(i, { qty: 0 })
                        }}
                        placeholder="0"
                      />
                    </td>
                    <td className="px-3 py-2.5 align-middle">
                      <input
                        className={`${inputClass} text-right tabular-nums`}
                        type="number"
                        min={0}
                        step="any"
                        value={row.rate || ''}
                        onChange={(e) => {
                          const v = e.target.value
                          if (v === '') {
                            updateRow(i, { rate: 0, manualRateEdited: true })
                            return
                          }
                          const n = Number(v)
                          updateRow(i, { rate: Number.isFinite(n) ? n : 0, manualRateEdited: true })
                        }}
                        placeholder="0"
                      />
                    </td>
                    <td className="px-3 py-2.5 align-middle text-right font-mono text-sm font-semibold tabular-nums text-slate-900">
                      {formatInrInteger(amount)}
                    </td>
                    <td className="px-3 py-2.5 align-middle text-center">
                      <button
                        type="button"
                        className="rounded-md p-1 text-slate-500 hover:bg-red-50 hover:text-red-600"
                        onClick={() => removeItemRow(i)}
                        aria-label={`Remove item row ${i + 1}`}
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-6 rounded-lg border border-slate-200 bg-slate-50 p-5">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div className="grid grid-cols-2 gap-x-8 gap-y-4 sm:flex sm:flex-wrap sm:items-end sm:gap-8">
              <Metric label="Total Qty" value={formatInQty(totals.totalQty, 'kg')} />
              <Metric label="Line items" value={formatInrInteger(totals.itemsTotal)} />
              <Metric label="Transport" value={formatInrInteger(transport)} />
              <Metric label="GST" value={formatInrInteger(totals.gstAmount)} />
              <Metric label={previousBalanceAmount >= 0 ? 'Previous Balance' : 'Previous Advance'} value={formatInrInteger(Math.abs(previousBalanceAmount))} />
              <Metric label="Sub Total" value={formatInrInteger(subTotalBeforeCredits)} />
              <Metric label="Credits" value={`- ${formatInrInteger(totalCredits)}`} />
            </div>
            <div className="text-left lg:text-right">
              <p className="text-xs text-slate-400">{payableAfterAdjustments >= 0 ? 'Amount Due' : 'Advance Balance'}</p>
              <p className="mt-1 font-mono text-3xl font-bold tabular-nums text-slate-900">{formatInrInteger(Math.abs(payableAfterAdjustments))}</p>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-500">{helperStatusText}</span>
          <div className="flex-1" />
          <button type="button" className="px-1 py-1 text-sm font-medium text-slate-600 underline-offset-2 hover:text-slate-900 hover:underline" onClick={resetForm}>
            Clear
          </button>
          <button
            type="button"
            className="rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
            onClick={openPreview}
            disabled={saveMutation.isPending || customersQuery.isLoading || itemsQuery.isLoading}
          >
            {saveMutation.isPending ? 'Saving...' : 'Save Bill'}
          </button>
        </div>
      </section>

      {isPreviewOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-900/60 p-4">
          <div className="max-h-[92vh] w-full max-w-5xl overflow-hidden rounded-xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
              <h3 className="text-base font-semibold text-slate-900">Bill Preview & Confirmation</h3>
              <button type="button" className="rounded-md px-2 py-1 text-sm text-slate-500 hover:bg-slate-100" onClick={() => setIsPreviewOpen(false)}>
                Close
              </button>
            </div>
            <div className="max-h-[70vh] overflow-auto p-4">
              <div
                ref={previewRef}
                className="mx-auto rounded-md border border-slate-300 bg-white p-2 text-[10px] text-slate-800"
                style={{ width: '11cm', minHeight: '18cm' }}
              >
                <div className="mb-1 border-b border-slate-300 pb-1 text-center text-[12px] font-semibold tracking-wide">
                  {COMPANY_NAME}
                </div>
                <div className="mb-1 flex items-center justify-between border-b border-slate-300 pb-1 text-[11px]">
                  <div>No. <span className="font-semibold">{String(bookNo).padStart(3, '0')}/{String(billNo).padStart(3, '0')}</span></div>
                  <div>Date : <span className="font-semibold">{date}</span></div>
                </div>
                <div className="mb-1 border-b border-slate-300 pb-1">
                  <span className="mr-1 font-semibold">M/s.</span>
                  <span>{selectedCustomerName}</span>
                </div>

                <table className="w-full border-collapse text-[10px]">
                  <thead>
                    <tr className="bg-slate-50">
                      <th className="w-[7%] border border-slate-300 px-1 py-1 text-left">Sr.</th>
                      <th className="w-[46%] border border-slate-300 px-1 py-1 text-left">Particulars</th>
                      <th className="w-[16%] border border-slate-300 px-1 py-1 text-right">Qty.</th>
                      <th className="w-[13%] border border-slate-300 px-1 py-1 text-right">Rate</th>
                      <th className="w-[18%] border border-slate-300 px-1 py-1 text-right">Amount Rs.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.from({ length: 14 }).map((_, idx) => {
                      const row = previewLineItems[idx]
                      return (
                        <tr key={idx}>
                          <td className="border border-slate-300 px-1 py-1 align-top text-[9px] text-slate-500">{row && !row.isMeta ? idx + 1 : ''}</td>
                          <td className="border border-slate-300 px-1 py-1 align-top">{row?.particulars ?? ''}</td>
                          <td className="border border-slate-300 px-1 py-1 text-right align-top font-mono">{row?.qty ?? ''}</td>
                          <td className="border border-slate-300 px-1 py-1 text-right align-top font-mono">{row?.rate ?? ''}</td>
                          <td className="border border-slate-300 px-1 py-1 text-right align-top font-mono">{row?.amount ?? ''}</td>
                        </tr>
                      )
                    })}
                    <tr>
                      <td colSpan={4} className="border border-slate-300 px-1 py-1 text-right font-semibold">Current Bill Total</td>
                      <td className="border border-slate-300 px-1 py-1 text-right font-mono text-[11px] font-semibold">{Math.round(totals.grandTotal).toLocaleString('en-IN')}</td>
                    </tr>
                    <tr>
                      <td colSpan={4} className="border border-slate-300 px-1 py-1 text-right font-semibold">Sub Total</td>
                      <td className="border border-slate-300 px-1 py-1 text-right font-mono text-[11px] font-semibold">{Math.round(subTotalBeforeCredits).toLocaleString('en-IN')}</td>
                    </tr>
                    <tr>
                      <td colSpan={4} className="border border-slate-300 px-1 py-1 text-right font-semibold">{payableAfterAdjustments >= 0 ? 'Amount Due' : 'Advance Balance'}</td>
                      <td className="border border-slate-300 px-1 py-1 text-right font-mono text-[12px] font-bold">{Math.round(Math.abs(payableAfterAdjustments)).toLocaleString('en-IN')}</td>
                    </tr>
                  </tbody>
                </table>

                <div className="mt-2 flex items-start justify-between">
                  <div className="space-y-1">
                    <p>Weight : <span className="font-semibold">{formatInQty(totals.totalQty, 'kg')}</span></p>
                    <p>Bags : <span className="font-semibold">{validRows.length || 0}</span></p>
                    <p>{previousBalanceAmount >= 0 ? 'Prev Bal' : 'Prev Advance'} [{previousBalanceDate}] : <span className="font-semibold">{Math.round(Math.abs(previousBalanceAmount)).toLocaleString('en-IN')}</span></p>
                    <p>Total Credits : <span className="font-semibold">-{Math.round(totalCredits).toLocaleString('en-IN')}</span></p>
                    <p className="mt-2 inline-block rounded-md border border-slate-400 px-2 py-1">
                      LR No. <span className="font-semibold">{lrList.length > 0 ? lrList.join(', ') : '-'}</span>
                    </p>
                  </div>
                  <div className="flex h-8 w-24 items-center justify-center rounded-full border border-slate-400 text-[11px] text-slate-500">
                    Signature
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-end gap-2 border-t border-slate-200 px-4 py-3">
              <button type="button" className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50" onClick={printPreview}>
                Print
              </button>
              <button type="button" className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50" onClick={() => void savePreviewAsJpg()}>
                Save JPG
              </button>
              <button type="button" className="rounded-md border border-green-300 bg-green-50 px-3 py-2 text-sm text-green-700 hover:bg-green-100" onClick={shareOnWhatsApp}>
                Share WhatsApp
              </button>
              <button type="button" className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50" onClick={() => setIsPreviewOpen(false)}>
                Back to Edit
              </button>
              <button
                type="button"
                className="rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
                onClick={() => void confirmAndSave()}
                disabled={saveMutation.isPending}
              >
                {saveMutation.isPending ? 'Saving...' : 'Confirm & Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-slate-600">{label}</span>
      {children}
    </label>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-[112px]">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="font-mono text-sm font-medium tabular-nums text-slate-800">{value}</p>
    </div>
  )
}

const inputClass =
  'h-10 w-full min-w-0 rounded-md border border-slate-300 bg-white px-2.5 text-sm text-slate-800 shadow-sm outline-none transition focus:border-slate-500 focus:ring-1 focus:ring-slate-400/30'
